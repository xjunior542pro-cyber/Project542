const geminiInput = document.getElementById("geminiInput");
const geminiBtn = document.getElementById("geminiBtn");
const geminiResult = document.getElementById("geminiResult");

geminiBtn.addEventListener("click", askGemini);
geminiInput.addEventListener("keydown", e => {
  if (e.key === "Enter") askGemini();
});

async function askGemini() {
  const text = geminiInput.value.trim();
  if (!text) return;

  geminiResult.textContent = "Thinking...";

  try {
    const res = await fetch(
      "https://apis.prexzyvilla.site/ai/gemini?text=" +
        encodeURIComponent(text)
    );
    const data = await res.json();

    geminiResult.textContent =
      data.reply || "No response from Gemini";
  } catch {
    geminiResult.textContent = "API error";
  }
}