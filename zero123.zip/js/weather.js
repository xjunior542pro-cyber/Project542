const input = document.getElementById("weatherInput");
const btn = document.getElementById("weatherBtn");
const result = document.getElementById("weatherResult");

btn.addEventListener("click", getWeather);
input.addEventListener("keydown", e => {
  if (e.key === "Enter") getWeather();
});

async function getWeather() {
  const city = input.value.trim();
  if (!city) return;

  result.textContent = "Loading weather...";

  try {
    const res = await fetch(
      `https://wttr.in/${encodeURIComponent(city)}?format=j1`
    );
    const data = await res.json();

    const current = data.current_condition[0];
    const today = data.weather[0];
    const astro = today.astronomy[0];

    result.innerHTML = `
      <strong style="color:#22d3ee">${city}</strong><br><br>

      🌡️ Temperature: ${current.temp_C}°C<br>
      🤗 Feels Like: ${current.FeelsLikeC}°C<br>
      💧 Humidity: ${current.humidity}%<br>
      💨 Wind: ${current.windspeedKmph} km/h<br>
      ☁️ Condition: ${current.weatherDesc[0].value}<br><br>

      🌅 Sunrise: ${astro.sunrise}<br>
      🌇 Sunset: ${astro.sunset}
    `;
  } catch (err) {
    result.textContent = "Weather not found.";
  }
}