const compressInput = document.getElementById("compressInput");
const qualityRange = document.getElementById("qualityRange");
const qualityValue = document.getElementById("qualityValue");
const compressBtn = document.getElementById("compressBtn");
const compressResult = document.getElementById("compressResult");

qualityRange.addEventListener("input", () => {
  qualityValue.textContent = qualityRange.value;
});

compressBtn.addEventListener("click", compressImage);

function compressImage() {
  const file = compressInput.files[0];
  const quality = qualityRange.value / 100;

  if (!file) {
    compressResult.textContent = "Please upload an image first.";
    return;
  }

  compressResult.textContent = "Compressing image...";

  const reader = new FileReader();
  reader.onload = function (e) {
    const img = new Image();
    img.onload = function () {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");

      canvas.width = img.width;
      canvas.height = img.height;

      ctx.drawImage(img, 0, 0);

      canvas.toBlob(
        (blob) => {
          const url = URL.createObjectURL(blob);

          const originalSize = (file.size / 1024).toFixed(2);
          const compressedSize = (blob.size / 1024).toFixed(2);

          compressResult.innerHTML = `
            <strong style="color:#22d3ee">Image Compressed</strong><br><br>

            <img src="${url}" style="max-width:100%; border-radius:8px;"><br><br>

            📦 Original: ${originalSize} KB<br>
            📉 Compressed: ${compressedSize} KB<br><br>

            <a href="${url}" download="compressed.jpg" style="
              display:inline-block;
              padding:8px 16px;
              background-color:#22d3ee;
              color:#020617;
              border-radius:8px;
              text-decoration:none;
              font-weight:bold;
            ">Download Image</a>
          `;
        },
        "image/jpeg",
        quality
      );
    };
    img.src = e.target.result;
  };

  reader.readAsDataURL(file);
}