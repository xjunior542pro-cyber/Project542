const ttInput = document.getElementById("ttInput");
const ttBtn = document.getElementById("ttBtn");
const ttResult = document.getElementById("ttResult");

ttBtn.addEventListener("click", fetchTikTok);
ttInput.addEventListener("keydown", e => {
  if (e.key === "Enter") fetchTikTok();
});

async function fetchTikTok() {
  const url = ttInput.value.trim();
  if (!url) return;

  ttResult.textContent = "Fetching video...";

  try {
    const res = await fetch(
      "https://www.tikwm.com/api/?url=" +
        encodeURIComponent(url)
    );
    const data = await res.json();

    if (!data.data) throw new Error();

    ttResult.innerHTML = `
      <strong style="color:#22d3ee">Video Found</strong><br><br>

      <a href="${data.data.play}" target="_blank">
        Download (No Watermark)
      </a>
      <br><br>

      <a href="${data.data.music}" target="_blank">
        Download Audio
      </a>
    `;
  } catch (err) {
    console.error(err);
    ttResult.textContent = "Failed to fetch TikTok video";
  }
}