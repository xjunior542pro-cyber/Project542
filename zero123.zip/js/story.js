const storyInput = document.getElementById("storyInput");
const storyBtn = document.getElementById("storyBtn");
const storyResult = document.getElementById("storyResult");

storyBtn.addEventListener("click", generateStory);
storyInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) generateStory();
});

async function generateStory() {
  const desc = storyInput.value.trim();
  if (!desc) {
    storyResult.textContent = "Please enter a description to generate a story.";
    return;
  }

  storyResult.textContent = "Generating story...";

  try {
    const res = await fetch(
      "https://apis.prexzyvilla.site/ai/story?description=" +
        encodeURIComponent(desc)
    );

    const data = await res.json();

    if (!data || !data.story) throw new Error("Story generation failed");

    storyResult.innerHTML = `
      <strong style="color:#22d3ee">Your Story</strong><br><br>
      <p style="white-space:pre-wrap; line-height:1.6;">${data.story}</p>
    `;
  } catch (err) {
    console.error(err);
    storyResult.textContent = "❌ Failed to generate story. Try again.";
  }
}