const upscaleInput = document.getElementById("upscaleInput");
const scaleFactor = document.getElementById("scaleFactor");
const upscaleBtn = document.getElementById("upscaleBtn");
const upscaleResult = document.getElementById("upscaleResult");

upscaleBtn.addEventListener("click", async () => {
  const file = upscaleInput.files[0];
  if (!file) {
    upscaleResult.textContent = "Please upload an image first.";
    return;
  }
  
  const factor = parseInt(scaleFactor.value) || 2;
  upscaleResult.textContent = "Upscaling image to Ultra HD...";
  
  const reader = new FileReader();
  reader.onload = function(e) {
    const img = new Image();
    img.onload = async function() {
      let currentCanvas = document.createElement("canvas");
      currentCanvas.width = img.width;
      currentCanvas.height = img.height;
      let ctx = currentCanvas.getContext("2d");
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(img, 0, 0);
      
      let targetWidth = img.width * factor;
      let targetHeight = img.height * factor;
      
      // Progressive upscale loop (double size each step)
      while (currentCanvas.width < targetWidth || currentCanvas.height < targetHeight) {
        const nextWidth = Math.min(currentCanvas.width * 2, targetWidth);
        const nextHeight = Math.min(currentCanvas.height * 2, targetHeight);
        
        const tempCanvas = document.createElement("canvas");
        tempCanvas.width = nextWidth;
        tempCanvas.height = nextHeight;
        const tempCtx = tempCanvas.getContext("2d");
        
        tempCtx.imageSmoothingEnabled = true;
        tempCtx.imageSmoothingQuality = "high";
        
        // Draw progressively scaled image
        tempCtx.drawImage(currentCanvas, 0, 0, currentCanvas.width, currentCanvas.height, 0, 0, nextWidth, nextHeight);
        
        currentCanvas = tempCanvas;
      }
      
      // Final output
      currentCanvas.toBlob((blob) => {
        const url = URL.createObjectURL(blob);
        
        upscaleResult.innerHTML = `
          <strong style="color:#22d3ee">Ultra HD Upscaled Image</strong><br><br>
          <img src="${url}" style="max-width:100%; border-radius:8px;"><br><br>
          <a href="${url}" download="upscaled-uhd.png" style="
            display:inline-block;
            padding:8px 16px;
            background-color:#22d3ee;
            color:#020617;
            border-radius:8px;
            text-decoration:none;
            font-weight:bold;
          ">Download Ultra HD Image</a>
        `;
      }, "image/png", 0.95);
      
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
});