const input = document.getElementById("query");
const btn = document.getElementById("searchBtn");
const result = document.getElementById("result");

btn.addEventListener("click", searchVerse);
input.addEventListener("keydown", e => {
  if (e.key === "Enter") searchVerse();
});

async function searchVerse() {
  const query = input.value.trim();
  if (!query) return;

  result.textContent = "Searching...";

  try {
    const res = await fetch(
      "https://bible-api.com/" + encodeURIComponent(query)
    );
    const data = await res.json();

    if (data.error) throw new Error();

    result.innerHTML = `
      <strong style="color:#22d3ee">${data.reference}</strong><br><br>
      ${data.text}
    `;
  } catch {
    result.textContent = "Verse not found";
  }
}