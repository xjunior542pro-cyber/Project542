const generateBtn = document.getElementById("generateBtn");
const usernameResult = document.getElementById("usernameResult");
const styleSelect = document.getElementById("styleSelect");

generateBtn.addEventListener("click", generateUsername);

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generateUsername() {
  const style = styleSelect.value;

  const styles = {
    epic: {
      first: ["Neo", "Dark", "Iron", "Storm", "Ghost", "Fire", "Shadow"],
      second: ["King", "Wolf", "Blade", "Titan", "Knight", "Rider"]
    },
    dark: {
      first: ["Void", "Ruin", "Night", "Blood", "Dread", "Grim"],
      second: ["Reaper", "Lord", "Phantom", "Wraith", "Demon"]
    },
    anime: {
      first: ["Akira", "Kuro", "Ryu", "Sora", "Itachi", "Ken"],
      second: ["Senpai", "X", "Kun", "Chan", "Blade", "Zero"]
    },
    tech: {
      first: ["Cyber", "Byte", "Null", "Neo", "Quantum", "Pixel"],
      second: ["Node", "Root", "Script", "AI", "404", "Dev"]
    }
  };

  const set = styles[style];

  const username =
    random(set.first) +
    random(set.second) +
    Math.floor(Math.random() * 999);

  usernameResult.innerHTML = `
    <strong style="color:#22d3ee">Generated Username</strong><br><br>
    <span style="
      font-size:20px;
      font-weight:bold;
      letter-spacing:1px;
    ">${username}</span>
  `;
}