const jsFileInput = document.getElementById("jsFileInput");
const jsCodeInput = document.getElementById("jsCodeInput");
const encryptBtn = document.getElementById("encryptBtn");
const encryptResult = document.getElementById("encryptResult");

encryptBtn.addEventListener("click", encryptJS);

// ============================
// SIMPLE BUT STRONG OBFUSCATION
// ============================
function obfuscate(code) {
  const encoded = btoa(
    encodeURIComponent(code)
    .split("")
    .reverse()
    .join("")
  );
  
  return `(function(){
  const _d = "${encoded}";
  const _f = decodeURIComponent(
    atob(_d).split("").reverse().join("")
  );
  try {
    eval(_f);
  } catch (e) {
    console.error("Execution blocked");
  }
})();`;
}

async function encryptJS() {
  encryptResult.textContent = "Encrypting...";
  
  let code = jsCodeInput.value.trim();
  
  // If file uploaded, read it
  const file = jsFileInput.files[0];
  if (file) {
    code = await file.text();
  }
  
  if (!code) {
    encryptResult.textContent = "Please provide JS code or upload a file.";
    return;
  }
  
  try {
    const encryptedCode = obfuscate(code);
    
    const blob = new Blob([encryptedCode], {
      type: "text/javascript"
    });
    const url = URL.createObjectURL(blob);
    
    encryptResult.innerHTML = `
      <strong style="color:#22d3ee">JS Encrypted Successfully</strong><br><br>

      <textarea readonly style="
        width:100%;
        height:160px;
        background:#020617;
        color:#22d3ee;
        border-radius:8px;
        padding:10px;
        font-family:monospace;
      ">${encryptedCode}</textarea>

      <br><br>

      <a href="${url}" download="encrypted.js" style="
        display:inline-block;
        padding:8px 16px;
        background-color:#22d3ee;
        color:#020617;
        border-radius:8px;
        text-decoration:none;
        font-weight:bold;
      ">Download Encrypted JS</a>
    `;
    
  } catch (err) {
    console.error(err);
    encryptResult.textContent = "❌ Encryption failed.";
  }
}