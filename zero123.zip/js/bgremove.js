const bgInput = document.getElementById("bgInput");
const bgBtn = document.getElementById("bgBtn");
const bgResult = document.getElementById("bgResult");

// 🔑 PUT YOUR remove.bg API KEY HERE
const REMOVE_BG_API_KEY = "jpmvKG7zY3MP3ivVo7viRfGN";

bgBtn.addEventListener("click", removeBackground);

async function removeBackground() {
  const file = bgInput.files[0];

  if (!file) {
    bgResult.textContent = "Please upload an image first.";
    return;
  }

  bgResult.textContent = "Removing background...";

  try {
    const formData = new FormData();
    formData.append("image_file", file);
    formData.append("size", "auto");

    const res = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers: {
        "X-Api-Key": REMOVE_BG_API_KEY
      },
      body: formData
    });

    if (!res.ok) {
      throw new Error("API request failed");
    }

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);

    bgResult.innerHTML = `
      <strong style="color:#22d3ee">Background Removed</strong><br><br>

      <img src="${url}" alt="Result" style="
        max-width:100%;
        border-radius:8px;
        background:checkerboard;
      "><br><br>

      <a href="${url}" download="no-bg.png" style="
        display:inline-block;
        padding:8px 16px;
        background-color:#22d3ee;
        color:#020617;
        border-radius:8px;
        text-decoration:none;
        font-weight:bold;
      ">Download PNG</a>
    `;

  } catch (err) {
    console.error(err);
    bgResult.textContent =
      "❌ Failed to remove background. API limit or invalid key.";
  }
}