const blurInput = document.getElementById("blurInput");
const blurBtn = document.getElementById("blurBtn");
const blurResult = document.getElementById("blurResult");
const blurRange = document.getElementById("blurRange");

blurBtn.addEventListener("click", applyBlur);

function applyBlur() {
  const file = blurInput.files[0];
  const intensity = blurRange.value;

  if (!file) {
    blurResult.textContent = "Please upload an image first.";
    return;
  }

  blurResult.textContent = "Applying blur...";

  const reader = new FileReader();
  reader.onload = function(e) {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");

      // Draw image normally
      ctx.drawImage(img, 0, 0);

      // Apply blur using CSS filter via temporary canvas
      ctx.filter = `blur(${intensity}px)`;
      ctx.drawImage(canvas, 0, 0);

      const url = canvas.toDataURL("image/jpeg");

      blurResult.innerHTML = `
        <strong style="color:#22d3ee">Blurred Image</strong><br><br>
        <img src="${url}" alt="Blurred" style="max-width:100%; border-radius:8px;">
        <br><br>
        <a href="${url}" download="blurred.jpg">Download Image</a>
      `;
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}