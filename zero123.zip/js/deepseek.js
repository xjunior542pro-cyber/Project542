const aiInput = document.getElementById("aiInput");
const aiBtn = document.getElementById("aiBtn");
const aiResult = document.getElementById("aiResult");

aiBtn.addEventListener("click", askAI);
aiInput.addEventListener("keydown", e => {
  if (e.key === "Enter") askAI();
});

async function askAI() {
  const text = aiInput.value.trim();
  if (!text) return;

  aiResult.textContent = "Thinking...";

  try {
    const res = await fetch(
      "https://apis.prexzyvilla.site/ai/deepseek?text=" +
        encodeURIComponent(text)
    );
    const data = await res.json();

    aiResult.textContent = data.reply || "No response";
  } catch {
    aiResult.textContent = "API error";
  }
}