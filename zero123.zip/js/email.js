const nameInput = document.getElementById("nameInput");
const domainSelect = document.getElementById("domainSelect");
const generateBtn = document.getElementById("generateBtn");
const emailResult = document.getElementById("emailResult");

function randomInt(max) {
  return Math.floor(Math.random() * max);
}

function cleanName(name) {
  return name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function generateRandomEmail(name, domain) {
  const clean = cleanName(name);
  const number = randomInt(9999);
  if (clean.length < 2) {
    // fallback random username
    const randomChars = Math.random().toString(36).slice(2, 8);
    return `${randomChars}${number}@${domain}`;
  }
  return `${clean}${number}@${domain}`;
}

generateBtn.addEventListener("click", () => {
  const name = nameInput.value.trim();
  const domain = domainSelect.value;

  const email1 = generateRandomEmail(name, domain);
  const email2 = generateRandomEmail(name, domain);
  const email3 = generateRandomEmail(name, domain);

  emailResult.innerHTML = `
    <div><strong>${email1}</strong> <button onclick="copyText('${email1}')">Copy</button></div>
    <div><strong>${email2}</strong> <button onclick="copyText('${email2}')">Copy</button></div>
    <div><strong>${email3}</strong> <button onclick="copyText('${email3}')">Copy</button></div>
  `;
});

function copyText(txt) {
  navigator.clipboard.writeText(txt);
  alert("Copied: " + txt);
}