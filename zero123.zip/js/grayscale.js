const imageInput = document.getElementById("imageInput");
const grayBtn = document.getElementById("grayBtn");
const grayResult = document.getElementById("grayResult");

grayBtn.addEventListener("click", convertGray);

async function convertGray() {
  const file = imageInput.files[0];
  if (!file) {
    grayResult.textContent = "Please upload an image first.";
    return;
  }
  
  grayResult.textContent = "Processing image...";
  
  try {
    const formData = new FormData();
    formData.append("apikey", "guru"); // as required by the API
    formData.append("file", file);
    
    const res = await fetch("https://discardapi.dpdns.org/api/image/grayscale", {
      method: "POST",
      body: formData
    });
    
    if (!res.ok) throw new Error("Failed to process image");
    
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    
    grayResult.innerHTML = `
      <strong style="color:#22d3ee">Grayscale Image</strong><br><br>
      <img src="${url}" alt="Grayscale" style="max-width:100%; border-radius:8px;">
      <br><br>
      <a href="${url}" download="grayscale.jpg">Download Image</a>
    `;
  } catch (err) {
    console.error(err);
    grayResult.textContent = "❌ Failed to convert image to grayscale.";
  }
}